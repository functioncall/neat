class App:

    def execute(self):
        pass
