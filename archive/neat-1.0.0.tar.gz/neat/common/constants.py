from enum import Enum     # for enum34, or the stdlib version


class KEYS(Enum):
    ROOT = "root"
